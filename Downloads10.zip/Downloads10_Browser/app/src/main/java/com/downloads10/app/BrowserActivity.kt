package com.downloads10.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.URLUtil
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class BrowserActivity : AppCompatActivity() {
    private data class Tab(var web: WebView, var title: String, var url: String)
    private data class LinkItem(var title: String, var url: String)

    private lateinit var container: FrameLayout
    private lateinit var address: EditText
    private lateinit var tabButton: TextView
    private var tabs = mutableListOf<Tab>()
    private var current = 0
    private var showingHome = true

    private var darkMode = false
    private var blockMedia = false
    private var desktopMode = false
    private var popupAllowed = false
    private var adBlock = false
    private var fontScale = 100

    private val bookmarks = mutableListOf<LinkItem>()
    private val shortcuts = mutableListOf<LinkItem>()

    companion object {
        private const val PREF = "browser10_v3"
        private const val HOME = "downloads10://home"
        private const val PICK_BOOKMARKS = 7001
        private const val CREATE_BOOKMARKS = 7002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSettings()
        buildUi()
        restoreTabs()
        showHome()
    }

    override fun onPause() {
        saveSession()
        super.onPause()
    }

    override fun onStop() {
        saveSession()
        super.onStop()
    }

    override fun onDestroy() {
        saveSession()
        super.onDestroy()
    }

    private fun loadSettings() {
        val p = getSharedPreferences(PREF, 0)
        darkMode = p.getBoolean("dark", false)
        blockMedia = p.getBoolean("media", false)
        desktopMode = p.getBoolean("desktop", false)
        popupAllowed = p.getBoolean("popups", false)
        adBlock = p.getBoolean("adblock", false)
        fontScale = p.getInt("font", 100)
        readLinks("bookmarks").forEach { bookmarks.add(it) }
        readLinks("shortcuts").forEach { shortcuts.add(it) }
    }

    private fun readLinks(key: String): List<LinkItem> {
        val raw = getSharedPreferences(PREF, 0).getString(key, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                LinkItem(o.optString("title", "رابط"), o.optString("url", ""))
            }.filter { it.url.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    private fun saveLinks() {
        fun encode(list: List<LinkItem>): String = JSONArray().apply {
            list.forEach { put(JSONObject().apply { put("title", it.title); put("url", it.url) }) }
        }.toString()
        getSharedPreferences(PREF, 0).edit()
            .putString("bookmarks", encode(bookmarks))
            .putString("shortcuts", encode(shortcuts))
            .putBoolean("dark", darkMode)
            .putBoolean("media", blockMedia)
            .putBoolean("desktop", desktopMode)
            .putBoolean("popups", popupAllowed)
            .putBoolean("adblock", adBlock)
            .putInt("font", fontScale)
            .apply()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val w = WebView(this)
        w.setBackgroundColor(Color.BLACK)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadsImagesAutomatically = !blockMedia
        s.blockNetworkImage = blockMedia
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.textZoom = fontScale
        s.setSupportMultipleWindows(popupAllowed)
        s.javaScriptCanOpenWindowsAutomatically = popupAllowed
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = userAgent()

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        applyDark(w)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return isBlocked(request.url.toString())
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (isBlocked(u) || (blockMedia && isMedia(u))) {
                    return WebResourceResponse("text/plain", "utf-8", null)
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (tabs.isNotEmpty() && current in tabs.indices) {
                    tabs[current].url = url
                    tabs[current].title = view.title?.ifBlank { url } ?: url
                }
                address.setText(url)
                saveSession()
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView, title: String) {
                if (tabs.isNotEmpty() && current in tabs.indices) tabs[current].title = title
                tabButton.text = "☰"
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
                if (!popupAllowed) return false
                val child = createWebView()
                val tab = Tab(child, "صفحة جديدة", "about:blank")
                tabs.add(tab)
                current = tabs.lastIndex
                showingHome = false
                container.removeAllViews()
                container.addView(child, FrameLayout.LayoutParams(-1, -1))
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = child
                resultMsg.sendToTarget()
                saveSession()
                return true
            }
        }

        w.setDownloadListener { url, _, disposition, mime, _ ->
            val name = URLUtil.guessFileName(url, disposition, mime)
            val item = DownloadRepository.add(this, url, name)
            DownloadServiceStart.start(this, item.id)
            Toast.makeText(this, "أضيف إلى مدير التنزيل", Toast.LENGTH_SHORT).show()
        }
        return w
    }

    private fun userAgent(): String = if (desktopMode) {
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
    } else WebSettings.getDefaultUserAgent(this)

    private fun applyDark(w: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, darkMode)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(w.settings, if (darkMode) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(5, 5, 5, 5)
            setBackgroundColor(Color.rgb(45, 45, 45))
        }
        tabButton = topButton("☰") { menu() }
        bar.addView(tabButton, LinearLayout.LayoutParams(56, 56))
        bar.addView(topButton("+") { tabsDialog() }, LinearLayout.LayoutParams(56, 56))
        address = EditText(this).apply {
            setSingleLine(true); hint = "عنوان أو بحث"; textSize = 16f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(14, 0, 14, 0); setBackgroundColor(Color.rgb(70,70,70))
            setOnEditorActionListener { _, _, _ -> navigate(text.toString()); true }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 56, 1f).apply { setMargins(5,0,5,0) })
        bar.addView(topButton("★") { addBookmark() }, LinearLayout.LayoutParams(56,56))
        bar.addView(topButton("⌂") { showHome() }, LinearLayout.LayoutParams(56,56))
        root.addView(bar)
        container = FrameLayout(this)
        root.addView(container, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun topButton(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY)
        setOnClickListener { action() }
    }

    private fun restoreTabs() {
        val raw = getSharedPreferences(PREF,0).getString("tabs", "") ?: ""
        if (raw.isBlank()) return
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url", "")
                if (url.isNotBlank() && url != HOME) {
                    val w = createWebView()
                    tabs.add(Tab(w, o.optString("title", url), url))
                    w.loadUrl(url)
                }
            }
            current = getSharedPreferences(PREF,0).getInt("current", 0).coerceIn(0, (tabs.size-1).coerceAtLeast(0))
        }
    }

    private fun saveSession() {
        val arr = JSONArray()
        tabs.forEach { t ->
            val u = t.web.url ?: t.url
            if (u.isNotBlank() && u != HOME) arr.put(JSONObject().apply { put("url",u); put("title",t.title) })
        }
        getSharedPreferences(PREF,0).edit().putString("tabs",arr.toString()).putInt("current",current).apply()
        saveLinks()
    }

    private fun showHome() {
        showingHome = true
        address.setText("")
        container.removeAllViews()
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,22,16,24); setBackgroundColor(Color.BLACK) }
        val search = EditText(this).apply {
            hint="بحث أو عنوان"; textSize=17f; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(18,0,18,0); setBackgroundColor(Color.rgb(55,55,55))
            setOnEditorActionListener { _,_,_ -> navigate(text.toString()); true }
        }
        root.addView(search, LinearLayout.LayoutParams(-1,58))
        val plus = TextView(this).apply { text="+"; textSize=30f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(85,85,85)); setOnClickListener{addShortcutDialog()} }
        root.addView(plus, LinearLayout.LayoutParams(58,58).apply{gravity=Gravity.CENTER; topMargin=18; bottomMargin=18})
        val grid = GridLayout(this).apply { columnCount=3 }
        shortcuts.forEachIndexed { i, link -> grid.addView(shortcutView(link,i)) }
        root.addView(grid, LinearLayout.LayoutParams(-1,-2))
        scroll.addView(root)
        container.addView(scroll, FrameLayout.LayoutParams(-1,-1))
    }

    private fun shortcutView(link: LinkItem, index: Int): View {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(8,12,8,12); setBackgroundColor(Color.rgb(28,28,28)) }
        val icon = TextView(this).apply { text="🌐"; textSize=28f; gravity=Gravity.CENTER }
        val name = TextView(this).apply { text=link.title; textSize=13f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; maxLines=2 }
        box.addView(icon, LinearLayout.LayoutParams(-1,48)); box.addView(name)
        box.setOnClickListener { openShortcut(link) }
        box.setOnLongClickListener { shortcutActions(index); true }
        val p=GridLayout.LayoutParams(); p.width=0; p.height=120; p.columnSpec=GridLayout.spec(index%3,1f); p.setMargins(6,6,6,6); box.layoutParams=p
        return box
    }

    private fun addShortcutDialog() {
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,10,30,0)}
        val name=EditText(this).apply{hint="اسم الموقع"}
        val url=EditText(this).apply{hint="https://example.com";setSingleLine(true)}
        layout.addView(name); layout.addView(url)
        AlertDialog.Builder(this).setTitle("إضافة موقع").setView(layout).setPositiveButton("حفظ"){_,_->
            val u=normalizeUrl(url.text.toString()); if(u.isNotBlank()){shortcuts.add(LinkItem(name.text.toString().ifBlank{hostName(u)},u));saveLinks();showHome()}
        }.setNegativeButton("إلغاء",null).show()
    }

    private fun shortcutActions(index:Int){
        AlertDialog.Builder(this).setItems(arrayOf("إعادة تسمية","حذف","إلغاء")){_,w->when(w){0->renameShortcut(index);1->{shortcuts.removeAt(index);saveLinks();showHome()}}}.show()
    }

    private fun renameShortcut(index:Int){
        val input=EditText(this).apply{setSingleLine(true);setText(shortcuts[index].title)}
        AlertDialog.Builder(this).setTitle("إعادة تسمية").setView(input).setPositiveButton("حفظ"){_,_->shortcuts[index].title=input.text.toString().ifBlank{shortcuts[index].title};saveLinks();showHome()}.setNegativeButton("إلغاء",null).show()
    }

    private fun openShortcut(link:LinkItem){showingHome=false;ensureTab();currentWeb().loadUrl(link.url);address.setText(link.url)}

    private fun ensureTab(){
        if(tabs.isEmpty()){val w=createWebView();tabs.add(Tab(w,"صفحة جديدة","about:blank"));current=0;container.removeAllViews();container.addView(w,FrameLayout.LayoutParams(-1,-1))}
        else selectTab(current)
    }

    private fun navigate(raw:String){
        val q=raw.trim();if(q.isBlank())return
        val u=normalizeUrl(q)
        showingHome=false;ensureTab();currentWeb().loadUrl(u);address.setText(u);address.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken,0)
    }

    private fun normalizeUrl(q:String):String=if(q.startsWith("http://")||q.startsWith("https://"))q else if(q.contains(".")&&!q.contains(" "))"https://$q" else "https://www.google.com/search?q="+URLEncoder.encode(q,"UTF-8")
    private fun hostName(u:String)=runCatching{Uri.parse(u).host ?: u}.getOrDefault(u)

    private fun currentWeb():WebView=tabs[current].web

    private fun addTab(url:String="about:blank"){
        val w=createWebView();tabs.add(Tab(w,"صفحة جديدة",url));current=tabs.lastIndex;showingHome=false;container.removeAllViews();container.addView(w,FrameLayout.LayoutParams(-1,-1));if(url!="about:blank")w.loadUrl(url);saveSession()
    }

    private fun selectTab(i:Int){if(i !in tabs.indices)return;current=i;showingHome=false;container.removeAllViews();container.addView(tabs[i].web,FrameLayout.LayoutParams(-1,-1));address.setText(tabs[i].web.url?:tabs[i].url)}

    private fun tabsDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        tabs.forEachIndexed{index,t->
            val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(12,8,8,8)}
            val title=TextView(this).apply{text="${index+1}. ${t.title.ifBlank{"صفحة"}}";textSize=16f;setTextColor(Color.WHITE);setPadding(4,0,4,0)}
            val x=TextView(this).apply{text="✕";textSize=24f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER}
            row.setBackgroundColor(Color.rgb(40,40,40));row.addView(title,LinearLayout.LayoutParams(0,54,1f));row.addView(x,LinearLayout.LayoutParams(54,54))
            title.setOnClickListener{selectTab(index);dialog.dismiss()};x.setOnClickListener{closeTab(index);dialog.dismiss()};box.addView(row,LinearLayout.LayoutParams(-1,60).apply{bottomMargin=5})
        }
        val newBtn=Button(this).apply{text="+ صفحة جديدة";setOnClickListener{addTab();dialog.dismiss()}}
        val closeAll=Button(this).apply{text="إغلاق كل الصفحات";setOnClickListener{tabs.forEach{it.web.destroy()};tabs.clear();saveSession();showHome();dialog.dismiss()}}
        box.addView(newBtn);box.addView(closeAll)
        dialog=AlertDialog.Builder(this).setTitle("الصفحات المفتوحة").setView(box).create();dialog.show()
    }
    private lateinit var dialog:AlertDialog

    private fun closeTab(index:Int){if(index !in tabs.indices)return;tabs[index].web.destroy();tabs.removeAt(index);if(tabs.isEmpty()){showHome();return};current=current.coerceIn(0,tabs.lastIndex);selectTab(current);saveSession()}

    private fun addBookmark(){if(tabs.isEmpty())return;val u=currentWeb().url?:return;if(u=="about:blank")return;val title=currentWeb().title?.ifBlank{hostName(u)}?:hostName(u);if(bookmarks.none{it.url==u})bookmarks.add(LinkItem(title,u));saveLinks();Toast.makeText(this,"تمت إضافة العلامة المرجعية",Toast.LENGTH_SHORT).show()}

    private fun menu(){
        val items=arrayOf("↓ فتح مدير التنزيل","العلامات المرجعية","مانع الإعلانات: ${if(adBlock)"مفعّل"else"متوقف"}","الوضع الداكن: ${if(darkMode)"مفعّل"else"متوقف"}","حجم الخط","ترجمة إلى العربية","وضع سطح المكتب: ${if(desktopMode)"مفعّل"else"متوقف"}","حجب الصور والفيديو: ${if(blockMedia)"مفعّل"else"متوقف"}","النوافذ المنبثقة: ${if(popupAllowed)"مسموح"else""ممنوع"}","اختيار ملف من الجهاز")
        AlertDialog.Builder(this).setTitle("☰ المتصفح").setItems(items){_,w->when(w){0->finish();1->bookmarksDialog();2->{adBlock=!adBlock;saveLinks();currentWebOrNull()?.reload()};3->{darkMode=!darkMode;saveLinks();applyAll()};4->fontDialog();5->translateCurrent();6->{desktopMode=!desktopMode;saveLinks();applyAll()};7->{blockMedia=!blockMedia;saveLinks();applyAll()};8->{popupAllowed=!popupAllowed;saveLinks();applyAll()};9->pickLocalFile()}}.show()
    }

    private fun currentWebOrNull()=tabs.getOrNull(current)?.web

    private fun bookmarksDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        bookmarks.forEachIndexed{index,b->
            val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(8,6,8,6);setBackgroundColor(Color.rgb(38,38,38))}
            val t=TextView(this).apply{text=b.title;textSize=16f;setTextColor(Color.WHITE);setPadding(8,0,8,0)}
            val x=TextView(this).apply{text="✕";textSize=23f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER}
            row.addView(t,LinearLayout.LayoutParams(0,54,1f));row.addView(x,LinearLayout.LayoutParams(54,54));box.addView(row,LinearLayout.LayoutParams(-1,60).apply{bottomMargin=5})
            t.setOnClickListener{ensureTab();currentWeb().loadUrl(b.url);bmDialog.dismiss()};x.setOnClickListener{bookmarks.removeAt(index);saveLinks();bmDialog.dismiss();bookmarksDialog()}
        }
        val exp=Button(this).apply{text="تصدير HTML إلى Download";setOnClickListener{exportBookmarks();bmDialog.dismiss()}}
        val imp=Button(this).apply{text="استيراد HTML";setOnClickListener{pickBookmarks();bmDialog.dismiss()}}
        box.addView(exp);box.addView(imp)
        bmDialog=AlertDialog.Builder(this).setTitle("العلامات المرجعية").setView(box).create();bmDialog.show()
    }
    private lateinit var bmDialog:AlertDialog

    private fun exportBookmarks(){
        val html="""<!doctype html><html><head><meta charset="utf-8"><title>Downloads10 Bookmarks</title></head><body><h1>Downloads10</h1>${bookmarks.joinToString("\n"){"<a href=\"${escape(it.url)}\">${escape(it.title)}</a><br>"}}</body></html>"""
        val values=android.content.ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"Downloads10-bookmarks.html");put(MediaStore.Downloads.MIME_TYPE,"text/html");put(MediaStore.Downloads.IS_PENDING,1)}
        val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
        if(uri!=null){contentResolver.openOutputStream(uri)?.use{it.write(html.toByteArray(Charsets.UTF_8))};values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);contentResolver.update(uri,values,null,null);Toast.makeText(this,"تم حفظ العلامات في Download",Toast.LENGTH_LONG).show()}else Toast.makeText(this,"تعذر إنشاء الملف",Toast.LENGTH_LONG).show()
    }
    private fun escape(s:String)=s.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;")

    private fun pickBookmarks(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/html"},PICK_BOOKMARKS)}
    private fun pickLocalFile(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"},PICK_BOOKMARKS+1)}

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!;when(requestCode){PICK_BOOKMARKS->importHtml(uri);PICK_BOOKMARKS+1->openLocalFile(uri)}}

    private fun importHtml(uri:Uri){val html=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:return;val re=Regex("<a[^>]+href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</a>",RegexOption.IGNORE_CASE);re.findAll(html).forEach{m->val u=android.text.Html.fromHtml(m.groupValues[1],android.text.Html.FROM_HTML_MODE_LEGACY).toString();val title=android.text.Html.fromHtml(m.groupValues[2],android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim();if(u.startsWith("http"))bookmarks.add(LinkItem(title.ifBlank{u},u))};bookmarks.distinctBy{it.url}.also{bookmarks.clear();bookmarks.addAll(it)};saveLinks();Toast.makeText(this,"تم استيراد العلامات",Toast.LENGTH_SHORT).show()}
    private fun openLocalFile(uri:Uri){startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,contentResolver.getType(uri)?:("application/octet-stream"));addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})}

    private fun adPatterns()=listOf("doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","adnxs.com","taboola.com","outbrain.com","popads.","popcash.","propellerads.","adskeeper.","adroll.com","criteo.com","scorecardresearch.com","/ads/","/ad/","/advertising/","banner.")
    private fun isBlocked(url:String)=adBlock&&adPatterns().any{url.lowercase().contains(it)}
    private fun isMedia(url:String):Boolean{val u=url.lowercase();return listOf(".mp4",".webm",".m3u8",".mp3",".avi",".mov",".mkv","video/","audio/").any{u.contains(it)}}

    private fun applyAll(){tabs.forEach{t->t.web.settings.userAgentString=userAgent();t.web.settings.textZoom=fontScale;t.web.settings.loadsImagesAutomatically=!blockMedia;t.web.settings.blockNetworkImage=blockMedia;t.web.settings.setSupportMultipleWindows(popupAllowed);t.web.settings.javaScriptCanOpenWindowsAutomatically=popupAllowed;applyDark(t.web);t.web.reload()}}
    private fun fontDialog(){val v=arrayOf("80%","90%","100%","110%","125%","150%","175%","200%");AlertDialog.Builder(this).setTitle("حجم الخط").setItems(v){_,i->fontScale=v[i].removeSuffix("%").toInt();saveLinks();applyAll()}.show()}
    private fun translateCurrent(){val u=currentWebOrNull()?.url?:return;currentWeb().loadUrl("https://translate.google.com/translate?sl=auto&tl=ar&u="+URLEncoder.encode(u,"UTF-8"))}

    override fun onBackPressed(){if(showingHome){super.onBackPressed();return};val w=currentWebOrNull();if(w?.canGoBack()==true)w.goBack() else showHome()}
}
